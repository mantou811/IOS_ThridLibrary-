#import <Foundation/Foundation.h>

@interface NSURLRequest (DSL)
- (NSString *)toNocillaDSL;
@end
