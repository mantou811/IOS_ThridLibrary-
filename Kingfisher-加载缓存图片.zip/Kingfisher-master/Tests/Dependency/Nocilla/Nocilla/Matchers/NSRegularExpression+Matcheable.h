#import <Foundation/Foundation.h>
#import "LSMatcheable.h"

@interface NSRegularExpression (Matcheable) <LSMatcheable>

@end
