////////////////////////////////////////////////////////////////////////////
//
// Copyright 2014 Realm Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
////////////////////////////////////////////////////////////////////////////

#import "RLMTestCase.h"

#import "RLMRealmConfiguration_Private.h"
#import <Realm/RLMRealm_Private.h>
#import <Realm/RLMSchema_Private.h>
#import <Realm/RLMRealmConfiguration_Private.h>

static NSString *parentProcessBundleIdentifier(void)
{
    static BOOL hasInitializedIdentifier;
    static NSString *identifier;
    if (!hasInitializedIdentifier) {
        identifier = [NSProcessInfo processInfo].environment[@"RLMParentProcessBundleID"];
        hasInitializedIdentifier = YES;
    }

    return identifier;
}

NSURL *RLMDefaultRealmURL(void) {
    return [NSURL fileURLWithPath:RLMRealmPathForFileAndBundleIdentifier(@"default.realm", parentProcessBundleIdentifier())];
}

NSURL *RLMTestRealmURL(void) {
    return [NSURL fileURLWithPath:RLMRealmPathForFileAndBundleIdentifier(@"test.realm", parentProcessBundleIdentifier())];
}

static void deleteOrThrow(NSURL *fileURL) {
    NSError *error;
    if (![[NSFileManager defaultManager] removeItemAtURL:fileURL error:&error]) {
        if (error.code != NSFileNoSuchFileError) {
            @throw [NSException exceptionWithName:@"RLMTestException"
                                           reason:[@"Unable to delete realm: " stringByAppendingString:error.description]
                                         userInfo:nil];
        }
    }
}

NSData *RLMGenerateKey(void) {
    uint8_t buffer[64];
    (void)SecRandomCopyBytes(kSecRandomDefault, 64, buffer);
    return [[NSData alloc] initWithBytes:buffer length:sizeof(buffer)];
}

static BOOL encryptTests(void) {
    static BOOL encryptAll = NO;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (getenv("REALM_ENCRYPT_ALL")) {
            encryptAll = YES;
        }
    });
    return encryptAll;
}

@implementation RLMTestCaseBase
+ (void)setUp {
    [super setUp];
#if DEBUG || !TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR
    // Disable actually syncing anything to the disk to greatly speed up the
    // tests, but only when not running on device because it can't be
    // re-enabled and we need it enabled for performance tests
    RLMDisableSyncToDisk();
#endif
    // Don't bother disabling backups on our non-Realm files because it takes
    // a while and we're going to delete them anyway.
    RLMSetSkipBackupAttribute(false);

    if (!getenv("RLMProcessIsChild")) {
        [self preinitializeSchema];

        // Clean up any potentially lingering Realm files from previous runs
        [NSFileManager.defaultManager removeItemAtPath:RLMRealmPathForFile(@"") error:nil];
    }

    // Ensure the documents directory exists as it sometimes doesn't after
    // resetting the simulator
    [NSFileManager.defaultManager createDirectoryAtURL:RLMDefaultRealmURL().URLByDeletingLastPathComponent
                           withIntermediateDirectories:YES attributes:nil error:nil];
}

// This ensures the shared schema is initialized outside of of a test case,
// so if an exception is thrown, it will kill the test process rather than
// allowing hundreds of test cases to fail in strange ways
// This is overridden by RLMMultiProcessTestCase to support testing the schema init
+ (void)preinitializeSchema {
    [RLMSchema sharedSchema];
}

// A hook point for subclasses to override the cleanup
- (void)resetRealmState {
    [RLMRealm resetRealmState];
}
@end

@implementation RLMTestCase {
    dispatch_queue_t _bgQueue;
}

- (void)deleteFiles {
    // Clear cache
    [self resetRealmState];

    // Delete Realm files
    NSURL *directory = RLMDefaultRealmURL().URLByDeletingLastPathComponent;
    NSError *error = nil;
    for (NSString *file in [NSFileManager.defaultManager
                            contentsOfDirectoryAtPath:directory.path error:&error]) {
        deleteOrThrow([directory URLByAppendingPathComponent:file]);
    }
}

- (void)deleteRealmFileAtURL:(NSURL *)fileURL {
    deleteOrThrow(fileURL);
    deleteOrThrow([fileURL URLByAppendingPathExtension:@"lock"]);
    deleteOrThrow([fileURL URLByAppendingPathExtension:@"note"]);
}

- (BOOL)encryptTests {
    return encryptTests();
}

- (void)invokeTest {
    @autoreleasepool {
        [self deleteFiles];

        if (self.encryptTests) {
            RLMRealmConfiguration *configuration = [RLMRealmConfiguration rawDefaultConfiguration];
            configuration.encryptionKey = RLMGenerateKey();
        }
    }
    @autoreleasepool {
        [super invokeTest];
    }
    @autoreleasepool {
        if (_bgQueue) {
            dispatch_sync(_bgQueue, ^{});
            _bgQueue = nil;
        }
        [self deleteFiles];
    }
}

- (RLMRealm *)realmWithTestPath {
    return [RLMRealm realmWithURL:RLMTestRealmURL()];
}

- (RLMRealm *)realmWithTestPathAndSchema:(RLMSchema *)schema {
    RLMRealmConfiguration *configuration = [RLMRealmConfiguration defaultConfiguration];
    configuration.fileURL = RLMTestRealmURL();
    if (schema)
        configuration.customSchema = schema;
    else
        configuration.dynamic = true;
    return [RLMRealm realmWithConfiguration:configuration error:nil];
}

- (RLMRealm *)inMemoryRealmWithIdentifier:(NSString *)identifier {
    RLMRealmConfiguration *configuration = [RLMRealmConfiguration defaultConfiguration];
    configuration.encryptionKey = nil;
    configuration.inMemoryIdentifier = identifier;
    return [RLMRealm realmWithConfiguration:configuration error:nil];
}

- (RLMRealm *)readOnlyRealmWithURL:(NSURL *)fileURL error:(NSError **)error {
    RLMRealmConfiguration *configuration = [RLMRealmConfiguration defaultConfiguration];
    configuration.fileURL = fileURL;
    configuration.readOnly = true;
    return [RLMRealm realmWithConfiguration:configuration error:error];
}

- (void)waitForNotification:(NSString *)expectedNote realm:(RLMRealm *)realm block:(dispatch_block_t)block {
    XCTestExpectation *notificationFired = [self expectationWithDescription:@"notification fired"];
    __block RLMNotificationToken *token = [realm addNotificationBlock:^(NSString *note, RLMRealm *realm) {
        XCTAssertNotNil(note, @"Note should not be nil");
        XCTAssertNotNil(realm, @"Realm should not be nil");
        if (note == expectedNote) { // Check pointer equality to ensure we're using the interned string constant
            [notificationFired fulfill];
            [token invalidate];
        }
    }];

    dispatch_queue_t queue = dispatch_queue_create("background", 0);
    dispatch_async(queue, ^{
        @autoreleasepool {
            block();
        }
    });

    [self waitForExpectationsWithTimeout:30.0 handler:nil];

    // wait for queue to finish
    dispatch_sync(queue, ^{});
}

- (dispatch_queue_t)bgQueue {
    if (!_bgQueue) {
        _bgQueue = dispatch_queue_create("test background queue", 0);
    }
    return _bgQueue;
}

- (void)dispatchAsync:(RLM_SWIFT_SENDABLE dispatch_block_t)block {
    dispatch_async(self.bgQueue, ^{
        @autoreleasepool {
            block();
        }
    });
}

- (void)dispatchAsyncAndWait:(RLM_SWIFT_SENDABLE dispatch_block_t)block {
    [self dispatchAsync:block];
    dispatch_sync(_bgQueue, ^{});
}

- (id)nonLiteralNil {
    return nil;
}

@end

