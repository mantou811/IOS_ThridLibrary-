// A dummy module header to let us import RealmTestSupport in non-swiftpm builds
#import "RLMChildProcessEnvironment.h"
